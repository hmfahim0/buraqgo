# Placeholder for public assets
